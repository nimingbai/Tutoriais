package zombie.waves;

class Joe {
    boolean direction;
    int position = 12;
    int energy = 4;
    int score = 0;
    int attackDelay = 0;
    int hittedDelay = 0;
}