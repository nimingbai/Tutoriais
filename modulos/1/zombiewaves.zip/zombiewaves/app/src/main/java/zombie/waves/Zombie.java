package zombie.waves;

class Zombie {
    boolean direction;
    int moveDelay;
    int attackDelay;
    int hittedDelay = 0;
    int position = 12;
    int energy;
}